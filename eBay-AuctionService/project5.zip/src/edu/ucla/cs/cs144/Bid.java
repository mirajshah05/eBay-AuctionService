/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ucla.cs.cs144;

/**
 *
 * @author miraj
 */
public class Bid {
    public String Bidder_Location_content=null;
    public String Bidder_Country_content=null;
    public String Time_content;
    public String Amount_content;
    public String UserID;
    public String Rating;
}
